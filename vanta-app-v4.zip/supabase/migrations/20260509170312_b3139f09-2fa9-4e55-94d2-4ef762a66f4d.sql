
drop policy "anyone can insert chat" on public.chat_messages;
drop policy "anyone can delete chat" on public.chat_messages;

create policy "insert chat with conv id" on public.chat_messages
  for insert
  with check (length(conversation_id) between 8 and 128 and length(content) between 1 and 8000);

create policy "delete own conv" on public.chat_messages
  for delete
  using (length(conversation_id) between 8 and 128);
