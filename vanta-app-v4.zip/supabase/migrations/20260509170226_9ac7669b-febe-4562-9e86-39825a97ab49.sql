
create table public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id text not null,
  role text not null check (role in ('user','assistant','system')),
  content text not null,
  created_at timestamptz not null default now()
);

create index chat_messages_conv_idx on public.chat_messages(conversation_id, created_at);

alter table public.chat_messages enable row level security;

-- Public anonymous chat — single device-scoped conversation. Anyone with the conv id can read/write.
create policy "anyone can read chat" on public.chat_messages for select using (true);
create policy "anyone can insert chat" on public.chat_messages for insert with check (true);
create policy "anyone can delete chat" on public.chat_messages for delete using (true);
